
dependancies:
	vbdevkit.dll 
	hexed.ocx   
	mscomctl.ocx  (microsoft common controls - not included)
	   
run install.bat to register controls.

Open a memory dump with embedded PE files in it,
this will parse out MZ markers, validate PE headers
and allow you to bulk extract them to disk.

See screen shot. 
