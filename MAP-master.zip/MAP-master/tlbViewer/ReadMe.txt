
this code was extracted from COMRaider